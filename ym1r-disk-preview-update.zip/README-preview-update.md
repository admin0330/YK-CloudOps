# Ym1r Disk online preview update

Replace the following files:

- `/opt/ym1r/server.js`
- `/opt/ym1r/src/api/client.ts`
- `/opt/ym1r/src/pages/DiskPage.tsx`

Supported online previews:

- Text and source files
- Markdown
- Sandboxed HTML
- PDF
- Images
- Office documents converted to cached PDF through LibreOffice: DOC, DOCX, PPT, PPTX, XLS, XLSX, ODT, ODS, ODP

After replacing the files, run:

```bash
cd /opt/ym1r
node --check server.js
npm run build
pm run start
```

If the app is managed by PM2, use your normal PM2 restart command instead of `npm run start`.
